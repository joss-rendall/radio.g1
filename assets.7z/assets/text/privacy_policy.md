**Privacy Policy**

Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. 

Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.

Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. 

Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.

**Information Collection and Use**

Aucune information personnelle n'est collectée.

Dans le cadre de l’utilisation de notre service, nous enregistrons l’adresse IP de connexion de chaque utilisateur. Cette information est stockée de manière sécurisée via notre infrastructure AzuraCast. La collecte de l’adresse IP est nécessaire pour assurer la sécurité, la gestion technique du service et le respect de la législation en vigueur. Les données collectées ne sont pas utilisées à des fins de profilage, mais uniquement pour la gestion technique et la prévention des abus.

Conformément à la réglementation applicable, vous disposez d’un droit d’accès, de rectification et de suppression de vos données personnelles. Pour toute demande relative à vos données, veuillez contacter notre support.